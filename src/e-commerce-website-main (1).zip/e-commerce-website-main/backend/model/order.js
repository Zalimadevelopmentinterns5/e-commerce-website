const mongoose = require('mongoose')

const orderSchema = new mongoose.Schema({
    userId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'user',
        required:true
    },
    products:[
        {
            productId:{
                type:mongoose.Schema.Types.ObjectId,
                ref:'product',
                required:true
            },
            quantity:{
                type:Number,
                required:true
            }
        }
    ],
    Price:{
        type:Number,
        required:true
    },
    status:{
        type:String,
        required:true,
        default:'pending'
    }
},{
    timestamps:true
}
)
const order = mongoose.model('order',orderSchema)
module.exports = order